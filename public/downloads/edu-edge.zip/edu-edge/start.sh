#!/usr/bin/env bash
# EDU Edge — one-command local bootstrap.
# Checks Docker, prepares config, brings the stack up, pulls the local LLM model,
# and opens the app in the browser. Re-run any time to update / restart.
set -euo pipefail
cd "$(dirname "$0")"

say() { printf '\033[1;36m[EDU Edge]\033[0m %s\n' "$*"; }
die() { printf '\033[1;31m[EDU Edge]\033[0m %s\n' "$*" >&2; exit 1; }

# 1. Docker present + running?
command -v docker >/dev/null 2>&1 || die "Docker não encontrado. Instale o Docker Desktop (ou Podman/Rancher Desktop) e rode de novo."
docker info >/dev/null 2>&1 || die "O Docker não está rodando. Abra o Docker Desktop e tente de novo."

# compose v2 (docker compose) or v1 (docker-compose)?
if docker compose version >/dev/null 2>&1; then DC="docker compose"; else command -v docker-compose >/dev/null 2>&1 && DC="docker-compose" || die "docker compose não disponível."; fi

# 2. First-run config
[ -f .env ] || { cp .env.example .env; say "Criado .env a partir do exemplo (ajuste a licença em EDU_LICENSE_KEY se quiser)."; }

PORT="$(grep -E '^EDU_HTTP_PORT=' .env | cut -d= -f2 || true)"; PORT="${PORT:-8080}"
MODEL="$(grep -E '^EDU_LLM_MODEL=' .env | cut -d= -f2 || true)"; MODEL="${MODEL:-llama3.1:8b}"

# 3. Up
say "Subindo os serviços (na primeira vez baixa as imagens, pode demorar)..."
$DC up -d

# 4. Pull the local LLM model once (idempotent)
say "Garantindo o modelo local '$MODEL' no Ollama (download único, alguns GB)..."
$DC exec -T ollama ollama pull "$MODEL" || say "Aviso: não consegui baixar o modelo agora; rode depois: $DC exec ollama ollama pull $MODEL"

# 5. Open the app
URL="http://localhost:${PORT}"
say "Pronto. EDU Edge em: $URL"
( command -v xdg-open >/dev/null && xdg-open "$URL" ) 2>/dev/null || \
( command -v open >/dev/null && open "$URL" ) 2>/dev/null || \
( command -v powershell.exe >/dev/null && powershell.exe -c "Start-Process '$URL'" ) 2>/dev/null || true
