-- ===========================================
-- EDU Platform - TimescaleDB Schema
-- Time Series Data Storage
-- ===========================================

-- Enable TimescaleDB extension
CREATE EXTENSION IF NOT EXISTS timescaledb;

-- ===========================================
-- Main MQTT Messages Table
-- ===========================================
CREATE TABLE IF NOT EXISTS mqtt_messages (
    id BIGSERIAL,
    topic TEXT NOT NULL,
    payload JSONB,
    qos SMALLINT DEFAULT 0,
    retain BOOLEAN DEFAULT false,
    tenant_id UUID,
    received_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Convert to hypertable (automatic time-based partitioning)
SELECT create_hypertable('mqtt_messages', 'received_at',
    chunk_time_interval => INTERVAL '1 hour',
    if_not_exists => TRUE
);

-- ===========================================
-- Indexes for Performance
-- ===========================================
CREATE INDEX IF NOT EXISTS idx_mqtt_topic ON mqtt_messages (topic);
CREATE INDEX IF NOT EXISTS idx_mqtt_tenant ON mqtt_messages (tenant_id);
CREATE INDEX IF NOT EXISTS idx_mqtt_received ON mqtt_messages (received_at DESC);
CREATE INDEX IF NOT EXISTS idx_mqtt_topic_time ON mqtt_messages (topic, received_at DESC);

-- ===========================================
-- Retention Policy (24 hours default, configurable via API)
-- ===========================================
SELECT add_retention_policy('mqtt_messages', INTERVAL '24 hours', if_not_exists => TRUE);

-- ===========================================
-- Tag Values Table (Latest values cache)
-- ===========================================
CREATE TABLE IF NOT EXISTS tag_latest_values (
    topic TEXT PRIMARY KEY,
    payload JSONB,
    qos SMALLINT DEFAULT 0,
    retain BOOLEAN DEFAULT false,
    tenant_id UUID,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_tag_tenant ON tag_latest_values (tenant_id);
CREATE INDEX IF NOT EXISTS idx_tag_updated ON tag_latest_values (updated_at DESC);

-- ===========================================
-- Continuous Aggregates for Metrics
-- ===========================================

-- Messages per minute aggregation
CREATE MATERIALIZED VIEW IF NOT EXISTS mqtt_stats_minute
WITH (timescaledb.continuous) AS
SELECT
    time_bucket('1 minute', received_at) AS bucket,
    topic,
    tenant_id,
    COUNT(*) as message_count,
    AVG((payload->>'value')::numeric) as avg_value,
    MIN((payload->>'value')::numeric) as min_value,
    MAX((payload->>'value')::numeric) as max_value
FROM mqtt_messages
WHERE payload->>'value' IS NOT NULL
GROUP BY bucket, topic, tenant_id
WITH NO DATA;

-- Refresh policy for continuous aggregate
SELECT add_continuous_aggregate_policy('mqtt_stats_minute',
    start_offset => INTERVAL '1 hour',
    end_offset => INTERVAL '1 minute',
    schedule_interval => INTERVAL '1 minute',
    if_not_exists => TRUE
);

-- Messages per hour aggregation (for dashboard)
CREATE MATERIALIZED VIEW IF NOT EXISTS mqtt_stats_hourly
WITH (timescaledb.continuous) AS
SELECT
    time_bucket('1 hour', received_at) AS bucket,
    topic,
    tenant_id,
    COUNT(*) as message_count,
    AVG((payload->>'value')::numeric) as avg_value,
    MIN((payload->>'value')::numeric) as min_value,
    MAX((payload->>'value')::numeric) as max_value
FROM mqtt_messages
WHERE payload->>'value' IS NOT NULL
GROUP BY bucket, topic, tenant_id
WITH NO DATA;

SELECT add_continuous_aggregate_policy('mqtt_stats_hourly',
    start_offset => INTERVAL '24 hours',
    end_offset => INTERVAL '1 hour',
    schedule_interval => INTERVAL '1 hour',
    if_not_exists => TRUE
);

-- ===========================================
-- Helper Functions
-- ===========================================

-- Function to get latest value for a topic
CREATE OR REPLACE FUNCTION get_latest_value(p_topic TEXT)
RETURNS TABLE (
    topic TEXT,
    payload JSONB,
    updated_at TIMESTAMPTZ
) AS $$
BEGIN
    RETURN QUERY
    SELECT
        tlv.topic,
        tlv.payload,
        tlv.updated_at
    FROM tag_latest_values tlv
    WHERE tlv.topic = p_topic;
END;
$$ LANGUAGE plpgsql;

-- Function to get topic history
CREATE OR REPLACE FUNCTION get_topic_history(
    p_topic TEXT,
    p_limit INT DEFAULT 100,
    p_from TIMESTAMPTZ DEFAULT NOW() - INTERVAL '1 hour'
)
RETURNS TABLE (
    payload JSONB,
    qos SMALLINT,
    received_at TIMESTAMPTZ
) AS $$
BEGIN
    RETURN QUERY
    SELECT
        mm.payload,
        mm.qos,
        mm.received_at
    FROM mqtt_messages mm
    WHERE mm.topic = p_topic
      AND mm.received_at >= p_from
    ORDER BY mm.received_at DESC
    LIMIT p_limit;
END;
$$ LANGUAGE plpgsql;

-- Function to update or insert latest value
CREATE OR REPLACE FUNCTION upsert_tag_value(
    p_topic TEXT,
    p_payload JSONB,
    p_qos SMALLINT DEFAULT 0,
    p_retain BOOLEAN DEFAULT false,
    p_tenant_id UUID DEFAULT NULL
)
RETURNS VOID AS $$
BEGIN
    INSERT INTO tag_latest_values (topic, payload, qos, retain, tenant_id, updated_at)
    VALUES (p_topic, p_payload, p_qos, p_retain, p_tenant_id, NOW())
    ON CONFLICT (topic)
    DO UPDATE SET
        payload = EXCLUDED.payload,
        qos = EXCLUDED.qos,
        retain = EXCLUDED.retain,
        tenant_id = COALESCE(EXCLUDED.tenant_id, tag_latest_values.tenant_id),
        updated_at = NOW();
END;
$$ LANGUAGE plpgsql;

-- ===========================================
-- Metrics Views for Dashboard
-- ===========================================

-- Current statistics view
CREATE OR REPLACE VIEW current_stats AS
SELECT
    COUNT(DISTINCT topic) as total_topics,
    COUNT(*) FILTER (WHERE received_at > NOW() - INTERVAL '1 minute') as messages_per_minute,
    COUNT(*) FILTER (WHERE received_at > NOW() - INTERVAL '1 hour') as messages_per_hour,
    COUNT(*) FILTER (WHERE received_at > NOW() - INTERVAL '1 day') as messages_per_day
FROM mqtt_messages
WHERE received_at > NOW() - INTERVAL '1 day';

COMMENT ON TABLE mqtt_messages IS 'Main table for storing MQTT messages with automatic time-based partitioning';
COMMENT ON TABLE tag_latest_values IS 'Cache table for latest values of each topic';
