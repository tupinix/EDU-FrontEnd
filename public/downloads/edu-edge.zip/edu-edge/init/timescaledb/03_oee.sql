-- OEE Calculator - Historical Snapshots
-- Fase 2.2

CREATE TABLE IF NOT EXISTS oee_snapshots (
    time TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    equipment_id UUID NOT NULL,
    availability DOUBLE PRECISION,
    performance DOUBLE PRECISION,
    quality DOUBLE PRECISION,
    oee DOUBLE PRECISION,
    run_minutes DOUBLE PRECISION DEFAULT 0,
    planned_minutes DOUBLE PRECISION DEFAULT 0,
    total_count INTEGER DEFAULT 0,
    good_count INTEGER DEFAULT 0
);

SELECT create_hypertable('oee_snapshots', 'time',
    chunk_time_interval => INTERVAL '1 day',
    if_not_exists => TRUE);

CREATE INDEX IF NOT EXISTS idx_oee_snapshots_equipment_time
    ON oee_snapshots (equipment_id, time DESC);

SELECT add_retention_policy('oee_snapshots', INTERVAL '365 days', if_not_exists => TRUE);
