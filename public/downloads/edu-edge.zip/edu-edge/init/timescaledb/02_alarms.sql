-- ===========================================
-- EDU Platform - Alarm Events (Time Series)
-- Stored in TimescaleDB for efficient historical queries
-- ===========================================

CREATE TABLE IF NOT EXISTS alarm_events (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    alarm_id UUID NOT NULL,
    alarm_name VARCHAR(255),
    topic VARCHAR(512),
    priority VARCHAR(20),
    state VARCHAR(30) NOT NULL,           -- active_unack, active_ack, rtn_unack, normal
    triggered_value DOUBLE PRECISION,
    triggered_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    acknowledged_by VARCHAR(255),
    acknowledged_at TIMESTAMPTZ,
    notes TEXT
);

-- Convert to hypertable (time-based partitioning by triggered_at)
SELECT create_hypertable('alarm_events', 'triggered_at',
    chunk_time_interval => INTERVAL '1 day',
    if_not_exists => TRUE
);

-- Indexes for common queries
CREATE INDEX IF NOT EXISTS idx_alarm_events_alarm_id ON alarm_events (alarm_id, triggered_at DESC);
CREATE INDEX IF NOT EXISTS idx_alarm_events_state ON alarm_events (state, triggered_at DESC);
CREATE INDEX IF NOT EXISTS idx_alarm_events_priority ON alarm_events (priority, triggered_at DESC);
CREATE INDEX IF NOT EXISTS idx_alarm_events_topic ON alarm_events (topic, triggered_at DESC);

-- Retention policy: keep 1 year of alarm history
SELECT add_retention_policy('alarm_events', INTERVAL '365 days', if_not_exists => TRUE);

COMMENT ON TABLE alarm_events IS 'Hypertable: historical log of all alarm state transitions (ISA-18.2)';
