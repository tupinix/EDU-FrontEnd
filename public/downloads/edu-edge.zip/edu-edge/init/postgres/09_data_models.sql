-- ===========================================
-- Data Models — UNS Modeling Layer
-- ===========================================

CREATE TABLE IF NOT EXISTS data_models (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    enabled BOOLEAN DEFAULT TRUE,

    -- Input
    source_topic VARCHAR(512) NOT NULL,
    source_broker_id VARCHAR(255),

    -- Output
    target_topic VARCHAR(512) NOT NULL,
    target_broker_id VARCHAR(255),

    -- ISA-95 context
    enterprise VARCHAR(255),
    site VARCHAR(255),
    area VARCHAR(255),
    line VARCHAR(255),
    equipment VARCHAR(255),
    tag_name VARCHAR(255),

    -- Enrichment
    unit VARCHAR(50),
    data_type VARCHAR(50),
    tag_description TEXT,

    -- Field mapping
    field_mappings JSONB DEFAULT '[]',
    extra_fields JSONB DEFAULT '{}',

    -- Stats
    messages_processed BIGINT DEFAULT 0,
    last_processed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_data_models_tenant ON data_models (tenant_id);
CREATE INDEX IF NOT EXISTS idx_data_models_source ON data_models (source_topic);
CREATE INDEX IF NOT EXISTS idx_data_models_enabled ON data_models (enabled) WHERE enabled = TRUE;

-- Trigger for updated_at
CREATE TRIGGER update_data_models_updated_at
    BEFORE UPDATE ON data_models
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();
