-- ===========================================
-- EDU Platform - Alarm Management System
-- Alarm Definitions & State Tables
-- ===========================================

-- Alarm Definitions (configured by engineers/admins)
CREATE TABLE IF NOT EXISTS alarm_definitions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    topic VARCHAR(512) NOT NULL,
    condition_type VARCHAR(50) NOT NULL,  -- threshold, bad_quality
    condition_config JSONB NOT NULL,       -- {operator: '>', value: 80, deadband: 2} or {timeoutSeconds: 60}
    priority VARCHAR(20) DEFAULT 'medium', -- critical, high, medium, low, info
    enabled BOOLEAN DEFAULT true,
    notification_channels JSONB DEFAULT '[]',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_alarm_def_tenant ON alarm_definitions (tenant_id);
CREATE INDEX IF NOT EXISTS idx_alarm_def_topic ON alarm_definitions (topic);
CREATE INDEX IF NOT EXISTS idx_alarm_def_enabled ON alarm_definitions (enabled);

-- Alarm States (current ISA-18.2 state for each alarm definition)
CREATE TABLE IF NOT EXISTS alarm_states (
    alarm_id UUID PRIMARY KEY REFERENCES alarm_definitions(id) ON DELETE CASCADE,
    state VARCHAR(30) DEFAULT 'normal',       -- normal, active_unack, active_ack, rtn_unack
    last_triggered_at TIMESTAMPTZ,
    last_value DOUBLE PRECISION,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Auto-insert alarm_state when alarm_definition is created
CREATE OR REPLACE FUNCTION create_alarm_state()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO alarm_states (alarm_id) VALUES (NEW.id)
    ON CONFLICT (alarm_id) DO NOTHING;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_create_alarm_state
    AFTER INSERT ON alarm_definitions
    FOR EACH ROW EXECUTE FUNCTION create_alarm_state();

-- updated_at triggers
CREATE TRIGGER update_alarm_definitions_updated_at
    BEFORE UPDATE ON alarm_definitions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

COMMENT ON TABLE alarm_definitions IS 'Alarm definitions configured by engineers - condition, priority and notification settings';
COMMENT ON TABLE alarm_states IS 'Current ISA-18.2 state for each alarm definition (normal, active_unack, active_ack, rtn_unack)';
