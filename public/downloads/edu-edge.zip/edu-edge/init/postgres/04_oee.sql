-- OEE Calculator - Equipment Definitions
-- Fase 2.2

CREATE TABLE IF NOT EXISTS oee_definitions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,

    -- Availability: machine status topic
    status_topic VARCHAR(512) NOT NULL,
    status_running_value TEXT NOT NULL DEFAULT '1',
    status_format VARCHAR(20) NOT NULL DEFAULT 'numeric', -- 'numeric' | 'string'

    -- Performance: parts count topic
    count_topic VARCHAR(512),
    ideal_cycle_seconds DOUBLE PRECISION NOT NULL DEFAULT 1.0,

    -- Quality: reject parts topic
    reject_topic VARCHAR(512),

    -- Schedule
    planned_hours_per_day DOUBLE PRECISION NOT NULL DEFAULT 8.0,

    enabled BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_oee_def_tenant ON oee_definitions (tenant_id);
CREATE INDEX IF NOT EXISTS idx_oee_def_enabled ON oee_definitions (enabled);
CREATE INDEX IF NOT EXISTS idx_oee_def_status_topic ON oee_definitions (status_topic);
