-- ===========================================
-- Process Dashboards — SCADA-like Canvas
-- ===========================================

CREATE TABLE IF NOT EXISTS process_dashboards (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL DEFAULT 'New Dashboard',
    description TEXT,
    canvas_width INTEGER DEFAULT 1920,
    canvas_height INTEGER DEFAULT 1080,
    background_color VARCHAR(20) DEFAULT '#1a1a2e',
    widgets JSONB DEFAULT '[]',
    is_default BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_dashboards_user ON process_dashboards (user_id);
CREATE INDEX IF NOT EXISTS idx_dashboards_tenant ON process_dashboards (tenant_id);

CREATE TRIGGER update_dashboards_updated_at
    BEFORE UPDATE ON process_dashboards
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();
