-- ===========================================
-- Waitlist — invite-only early access
-- ===========================================

CREATE TABLE IF NOT EXISTS waitlist_entries (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) NOT NULL UNIQUE,
    name VARCHAR(255),
    company VARCHAR(255),
    role VARCHAR(120),
    use_case TEXT,
    source VARCHAR(60) DEFAULT 'landing',
    ip VARCHAR(64),
    user_agent TEXT,
    locale VARCHAR(10),
    invited BOOLEAN DEFAULT FALSE,
    invited_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_waitlist_created  ON waitlist_entries (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_waitlist_invited  ON waitlist_entries (invited) WHERE invited = FALSE;
CREATE INDEX IF NOT EXISTS idx_waitlist_company  ON waitlist_entries (company);
