-- ===========================================
-- License Management
-- ===========================================

CREATE TABLE IF NOT EXISTS licenses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    license_key TEXT NOT NULL,
    customer_id VARCHAR(255),
    customer_name VARCHAR(255) NOT NULL,
    customer_email VARCHAR(255),
    plan VARCHAR(50) NOT NULL DEFAULT 'demo',
    edition VARCHAR(50) NOT NULL DEFAULT 'edge',
    max_devices INTEGER DEFAULT 1,
    features JSONB DEFAULT '{}',
    issued_at TIMESTAMPTZ DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL,
    revoked BOOLEAN DEFAULT FALSE,
    revoked_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_licenses_customer ON licenses (customer_email);
CREATE INDEX IF NOT EXISTS idx_licenses_plan ON licenses (plan);
CREATE INDEX IF NOT EXISTS idx_licenses_revoked ON licenses (revoked) WHERE revoked = FALSE;
