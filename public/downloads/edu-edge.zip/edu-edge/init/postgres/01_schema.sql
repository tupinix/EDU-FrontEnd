-- ===========================================
-- EDU Platform - PostgreSQL Config Database
-- Multi-tenant Configuration & RBAC
-- ===========================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ===========================================
-- Tenants Table
-- ===========================================
CREATE TABLE IF NOT EXISTS tenants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    subdomain VARCHAR(63) UNIQUE NOT NULL,
    mqtt_prefix VARCHAR(255) NOT NULL,
    status VARCHAR(50) DEFAULT 'active', -- active, suspended, trial
    plan VARCHAR(50) DEFAULT 'trial', -- trial, starter, professional, enterprise
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_tenant_subdomain ON tenants (subdomain);
CREATE INDEX idx_tenant_status ON tenants (status);

-- ===========================================
-- Users Table
-- ===========================================
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    email VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(255),
    role VARCHAR(50) NOT NULL DEFAULT 'viewer', -- admin, engineer, viewer
    status VARCHAR(50) DEFAULT 'active', -- active, suspended, pending
    last_login_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(tenant_id, email)
);

CREATE INDEX idx_user_tenant ON users (tenant_id);
CREATE INDEX idx_user_email ON users (email);
CREATE INDEX idx_user_role ON users (role);

-- ===========================================
-- Tenant Configuration
-- ===========================================
CREATE TABLE IF NOT EXISTS tenant_config (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID UNIQUE NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    hierarchy_config JSONB DEFAULT '{}', -- ISA-95 mapping configuration
    retention_hours INT DEFAULT 1,
    mqtt_topics TEXT[] DEFAULT '{}', -- Array of subscribed topics
    ui_settings JSONB DEFAULT '{}', -- UI customization settings
    notifications_enabled BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_config_tenant ON tenant_config (tenant_id);

-- ===========================================
-- ISA-95 Hierarchy Mappings
-- ===========================================
CREATE TABLE IF NOT EXISTS hierarchy_mappings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    topic_pattern VARCHAR(512) NOT NULL, -- MQTT topic pattern (can include wildcards)
    enterprise VARCHAR(255),
    site VARCHAR(255),
    area VARCHAR(255),
    line VARCHAR(255),
    equipment VARCHAR(255),
    tag_name VARCHAR(255),
    tag_type VARCHAR(100), -- temperature, pressure, status, etc.
    unit VARCHAR(50), -- Celsius, PSI, etc.
    description TEXT,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(tenant_id, topic_pattern)
);

CREATE INDEX idx_hierarchy_tenant ON hierarchy_mappings (tenant_id);
CREATE INDEX idx_hierarchy_pattern ON hierarchy_mappings (topic_pattern);

-- ===========================================
-- API Keys for External Integrations
-- ===========================================
CREATE TABLE IF NOT EXISTS api_keys (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    key_hash VARCHAR(255) NOT NULL,
    key_prefix VARCHAR(10) NOT NULL, -- First chars for identification
    permissions TEXT[] DEFAULT '{}', -- read, write, admin
    expires_at TIMESTAMPTZ,
    last_used_at TIMESTAMPTZ,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_apikey_tenant ON api_keys (tenant_id);
CREATE INDEX idx_apikey_prefix ON api_keys (key_prefix);

-- ===========================================
-- Audit Log
-- ===========================================
CREATE TABLE IF NOT EXISTS audit_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE SET NULL,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    action VARCHAR(100) NOT NULL, -- login, config_change, hierarchy_update, etc.
    resource_type VARCHAR(100), -- tenant, user, hierarchy, etc.
    resource_id UUID,
    details JSONB DEFAULT '{}',
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_audit_tenant ON audit_log (tenant_id);
CREATE INDEX idx_audit_user ON audit_log (user_id);
CREATE INDEX idx_audit_action ON audit_log (action);
CREATE INDEX idx_audit_created ON audit_log (created_at DESC);

-- ===========================================
-- Sessions (for JWT refresh tokens)
-- ===========================================
CREATE TABLE IF NOT EXISTS sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    refresh_token_hash VARCHAR(255) NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_session_user ON sessions (user_id);
CREATE INDEX idx_session_expires ON sessions (expires_at);

-- ===========================================
-- Connectors Configuration
-- ===========================================
CREATE TABLE IF NOT EXISTS connectors (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(100) NOT NULL, -- mqtt, opcua, modbus, s7, etc.
    config JSONB NOT NULL, -- Connection configuration (encrypted sensitive data)
    status VARCHAR(50) DEFAULT 'inactive', -- active, inactive, error
    last_connected_at TIMESTAMPTZ,
    error_message TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_connector_tenant ON connectors (tenant_id);
CREATE INDEX idx_connector_type ON connectors (type);
CREATE INDEX idx_connector_status ON connectors (status);

-- ===========================================
-- Helper Functions
-- ===========================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply trigger to all tables with updated_at
CREATE TRIGGER update_tenants_updated_at
    BEFORE UPDATE ON tenants
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_tenant_config_updated_at
    BEFORE UPDATE ON tenant_config
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_hierarchy_mappings_updated_at
    BEFORE UPDATE ON hierarchy_mappings
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_connectors_updated_at
    BEFORE UPDATE ON connectors
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ===========================================
-- Default Data
-- ===========================================

-- ===========================================
-- Bootstrap: default tenant + admin user
-- (Everything else is user-created via the UI)
-- ===========================================

INSERT INTO tenants (name, subdomain, mqtt_prefix, status, plan)
VALUES ('Tupinix', 'tupinix', 'Tupinix', 'active', 'professional')
ON CONFLICT (subdomain) DO NOTHING;

-- Default admin: admin@tupinix.com / admin123 — CHANGE PASSWORD ON FIRST LOGIN
INSERT INTO users (tenant_id, email, password_hash, name, role)
SELECT id, 'admin@tupinix.com',
       '$2b$10$wFaDor10/sGPgA9MuT61FuJsI/OxBgbLV68f0kYwJLStxtYJz65MC',
       'Admin', 'admin'
FROM tenants WHERE subdomain = 'tupinix'
ON CONFLICT (tenant_id, email) DO NOTHING;

INSERT INTO tenant_config (tenant_id, retention_hours, mqtt_topics)
SELECT id, 24, ARRAY['#']
FROM tenants WHERE subdomain = 'tupinix'
ON CONFLICT (tenant_id) DO NOTHING;

-- ===========================================
-- Views
-- ===========================================

-- Tenant summary view
CREATE OR REPLACE VIEW tenant_summary AS
SELECT
    t.id,
    t.name,
    t.subdomain,
    t.status,
    t.plan,
    COUNT(DISTINCT u.id) as user_count,
    COUNT(DISTINCT c.id) as connector_count,
    t.created_at
FROM tenants t
LEFT JOIN users u ON t.id = u.tenant_id
LEFT JOIN connectors c ON t.id = c.tenant_id
GROUP BY t.id;

COMMENT ON TABLE tenants IS 'Multi-tenant organizations';
COMMENT ON TABLE users IS 'Users with role-based access control';
COMMENT ON TABLE tenant_config IS 'Per-tenant configuration settings';
COMMENT ON TABLE hierarchy_mappings IS 'ISA-95 hierarchy mappings for MQTT topics';
COMMENT ON TABLE audit_log IS 'Audit trail for compliance and debugging';
