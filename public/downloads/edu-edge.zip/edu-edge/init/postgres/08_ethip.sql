-- ===========================================
-- EtherNet/IP Gateway Tables
-- ===========================================

-- EtherNet/IP PLC Connections
CREATE TABLE IF NOT EXISTS ethip_connections (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    host VARCHAR(255) NOT NULL,
    slot INTEGER NOT NULL DEFAULT 0,
    plc_type VARCHAR(50) DEFAULT 'logix',
    status VARCHAR(50) DEFAULT 'disconnected',
    plc_info JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ethip_connections_tenant ON ethip_connections (tenant_id);
CREATE INDEX IF NOT EXISTS idx_ethip_connections_status ON ethip_connections (status);

-- EtherNet/IP Tag Subscriptions (maps PLC tags to MQTT topics)
CREATE TABLE IF NOT EXISTS ethip_tags (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    connection_id UUID NOT NULL REFERENCES ethip_connections(id) ON DELETE CASCADE,
    tag_name VARCHAR(512) NOT NULL,
    display_name VARCHAR(255),
    data_type VARCHAR(50),
    mqtt_topic VARCHAR(512) NOT NULL,
    sampling_interval_ms INTEGER DEFAULT 1000,
    broker_id VARCHAR(255),
    enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ethip_tags_connection ON ethip_tags (connection_id);
CREATE INDEX IF NOT EXISTS idx_ethip_tags_topic ON ethip_tags (mqtt_topic);

-- Trigger for updated_at
CREATE TRIGGER update_ethip_connections_updated_at
    BEFORE UPDATE ON ethip_connections
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();
