-- ==========================================================
-- Rule Engine tables
-- ==========================================================

CREATE TABLE IF NOT EXISTS rules (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id         UUID REFERENCES tenants(id) ON DELETE CASCADE,
  name              VARCHAR(255) NOT NULL,
  description       TEXT,
  conditions        JSONB NOT NULL DEFAULT '[]',
  logic             VARCHAR(3) NOT NULL DEFAULT 'AND' CHECK (logic IN ('AND', 'OR')),
  actions           JSONB NOT NULL DEFAULT '[]',
  throttle_seconds  INTEGER NOT NULL DEFAULT 60,
  enabled           BOOLEAN NOT NULL DEFAULT true,
  last_triggered_at TIMESTAMPTZ,
  trigger_count     INTEGER NOT NULL DEFAULT 0,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_rules_tenant ON rules(tenant_id);
CREATE INDEX IF NOT EXISTS idx_rules_enabled ON rules(enabled);

-- Execution log
CREATE TABLE IF NOT EXISTS rule_executions (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  rule_id           UUID NOT NULL REFERENCES rules(id) ON DELETE CASCADE,
  triggered_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  condition_values  JSONB NOT NULL DEFAULT '{}',
  actions_executed  JSONB NOT NULL DEFAULT '[]'
);

CREATE INDEX IF NOT EXISTS idx_rule_executions_rule ON rule_executions(rule_id);
CREATE INDEX IF NOT EXISTS idx_rule_executions_time ON rule_executions(triggered_at DESC);

-- Anomaly detections
CREATE TABLE IF NOT EXISTS anomaly_detections (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   UUID REFERENCES tenants(id) ON DELETE CASCADE,
  topic       VARCHAR(512) NOT NULL,
  detected_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  type        VARCHAR(50) NOT NULL,   -- zscore, rate_of_change, flatline
  value       DOUBLE PRECISION,
  z_score     DOUBLE PRECISION,
  mean        DOUBLE PRECISION,
  std_dev     DOUBLE PRECISION,
  message     TEXT,
  acknowledged BOOLEAN NOT NULL DEFAULT false
);

CREATE INDEX IF NOT EXISTS idx_anomalies_topic      ON anomaly_detections(topic);
CREATE INDEX IF NOT EXISTS idx_anomalies_detected   ON anomaly_detections(detected_at DESC);
CREATE INDEX IF NOT EXISTS idx_anomalies_tenant     ON anomaly_detections(tenant_id);
