-- ===========================================
-- Modbus TCP Gateway Tables
-- ===========================================

-- Modbus TCP Connections
CREATE TABLE IF NOT EXISTS modbus_connections (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    host VARCHAR(255) NOT NULL,
    port INTEGER NOT NULL DEFAULT 502,
    unit_id INTEGER NOT NULL DEFAULT 1,
    timeout_ms INTEGER NOT NULL DEFAULT 5000,
    status VARCHAR(50) DEFAULT 'disconnected',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_modbus_connections_tenant ON modbus_connections (tenant_id);
CREATE INDEX IF NOT EXISTS idx_modbus_connections_status ON modbus_connections (status);

-- Modbus Registers to poll (maps addresses to MQTT topics)
CREATE TABLE IF NOT EXISTS modbus_registers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    connection_id UUID NOT NULL REFERENCES modbus_connections(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    register_type VARCHAR(20) NOT NULL,
    address INTEGER NOT NULL,
    data_type VARCHAR(20) DEFAULT 'uint16',
    scale_factor DECIMAL DEFAULT 1.0,
    mqtt_topic VARCHAR(512) NOT NULL,
    sampling_interval_ms INTEGER DEFAULT 1000,
    broker_id VARCHAR(255),
    enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_modbus_registers_connection ON modbus_registers (connection_id);
CREATE INDEX IF NOT EXISTS idx_modbus_registers_topic ON modbus_registers (mqtt_topic);

-- Trigger for updated_at
CREATE TRIGGER update_modbus_connections_updated_at
    BEFORE UPDATE ON modbus_connections
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();
