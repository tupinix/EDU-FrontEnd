-- ===========================================
-- Alert Rules — Tag-based alerting with webhook
-- ===========================================

CREATE TABLE IF NOT EXISTS alert_rules (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    enabled BOOLEAN DEFAULT TRUE,

    -- Source
    source_topic VARCHAR(512) NOT NULL,
    value_field VARCHAR(255) DEFAULT 'value',

    -- Thresholds
    good_min DECIMAL,
    good_max DECIMAL,
    warn_min DECIMAL,
    warn_max DECIMAL,
    -- Anything outside warn range = bad

    -- Notifications
    webhook_url TEXT,
    notify_discord BOOLEAN DEFAULT TRUE,
    notify_whatsapp BOOLEAN DEFAULT FALSE,
    whatsapp_to TEXT,
    notify_on_good BOOLEAN DEFAULT FALSE,
    notify_on_warn BOOLEAN DEFAULT TRUE,
    notify_on_bad BOOLEAN DEFAULT TRUE,

    -- Cooldown (seconds between notifications for same status)
    cooldown_seconds INTEGER DEFAULT 60,

    -- State tracking
    current_status VARCHAR(20) DEFAULT 'unknown',
    last_value DECIMAL,
    last_notified_at TIMESTAMPTZ,
    total_notifications INTEGER DEFAULT 0,

    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_alert_rules_tenant ON alert_rules (tenant_id);
CREATE INDEX IF NOT EXISTS idx_alert_rules_topic ON alert_rules (source_topic);
CREATE INDEX IF NOT EXISTS idx_alert_rules_enabled ON alert_rules (enabled) WHERE enabled = TRUE;

CREATE TRIGGER update_alert_rules_updated_at
    BEFORE UPDATE ON alert_rules
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();
