-- ===========================================
-- OPC-UA Gateway Tables
-- ===========================================

-- OPC-UA Server Connections
CREATE TABLE IF NOT EXISTS opcua_connections (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    endpoint_url VARCHAR(512) NOT NULL,
    security_mode VARCHAR(50) DEFAULT 'None',
    username VARCHAR(255),
    password_encrypted VARCHAR(512),
    status VARCHAR(20) DEFAULT 'disconnected',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_opcua_connections_tenant ON opcua_connections (tenant_id);
CREATE INDEX IF NOT EXISTS idx_opcua_connections_status ON opcua_connections (status);

-- OPC-UA Node Subscriptions (maps OPC-UA nodes to MQTT topics)
CREATE TABLE IF NOT EXISTS opcua_subscriptions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    connection_id UUID REFERENCES opcua_connections(id) ON DELETE CASCADE,
    node_id VARCHAR(512) NOT NULL,
    mqtt_topic VARCHAR(512) NOT NULL,
    sampling_interval_ms INTEGER DEFAULT 1000,
    enabled BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_opcua_subscriptions_connection ON opcua_subscriptions (connection_id);
CREATE INDEX IF NOT EXISTS idx_opcua_subscriptions_topic ON opcua_subscriptions (mqtt_topic);

-- Trigger for updated_at
CREATE TRIGGER update_opcua_connections_updated_at
    BEFORE UPDATE ON opcua_connections
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();
