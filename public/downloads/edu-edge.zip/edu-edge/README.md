# EDU Edge — instalação local (Docker)

EDU Edge roda inteiro na sua máquina, offline: bancos, backend (com o broker
UNS interno embutido), frontend e um LLM local (Ollama) para os recursos de IA.
Nada vai para a nuvem.

## Requisitos

- **Docker** (Docker Desktop no Windows/Mac, ou Docker Engine no Linux).
  Alternativas grátis para empresas: **Podman** ou **Rancher Desktop**.
- ~8 GB de RAM livres (o LLM local e os bancos consomem memória).
- ~10 GB de disco (imagens + o modelo Llama).

## Instalar e rodar

```bash
# 1. entre na pasta
cd edu-edge-docker

# 2. suba tudo (Linux/Mac)
./start.sh
```

No Windows (PowerShell), sem o script:

```powershell
copy .env.example .env
docker compose up -d
docker compose exec ollama ollama pull llama3.1:8b
start http://localhost:8080
```

Depois é só abrir **http://localhost:8080**.

## Licença

Cole a sua chave em `EDU_LICENSE_KEY` no arquivo `.env` (você recebe ao se
cadastrar). Sem licença válida os recursos ficam bloqueados.

## Atualizar

```bash
docker compose pull   # baixa a versão nova das imagens
docker compose up -d  # aplica sem perder seus dados
```

## Parar / remover

```bash
docker compose stop           # pausa (mantém os dados)
docker compose down           # remove os containers (mantém os volumes/dados)
docker compose down -v        # remove TUDO, inclusive os dados
```

## Aceleração por GPU (opcional, NVIDIA)

O LLM roda em CPU por padrão. Para usar GPU NVIDIA, instale o NVIDIA Container
Toolkit e adicione ao serviço `ollama` no `docker-compose.yml`:

```yaml
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: all
              capabilities: [gpu]
```

## Portas

Só a **8080** (o app) é exposta na sua máquina. Bancos e LLM ficam na rede
interna do Docker, para não conflitar com nada.
